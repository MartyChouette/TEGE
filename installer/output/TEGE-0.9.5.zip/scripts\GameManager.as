class GameManager : TegeBehavior {



    GameObject object;

    int mee = 0;


    void OnCreate() {
        // Called when the entity is created
        object.
    }

    void OnUpdate(float dt) {
        // Called every frame
    }

    void OnDestroy() {
        // Called when the entity is destroyed
    }
}
