class Time : TegeBehavior {


    public GameObject;
    
    void OnCreate() {
        // Called when the entity is created
    }

    void OnUpdate(float dt) {
        // Called every frame
    }

    void OnDestroy() {
        // Called when the entity is destroyed
    }
}
